package com.threecrabs.hackpoint.ui.signin

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import com.threecrabs.hackpoint.BaseViewModel

class SignInViewModel : BaseViewModel() {

}